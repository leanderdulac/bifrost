﻿#!/bin/bash
mono-service PagarMe.Bifrost.Service.exe